import bpy
from bpy.types import CollectionProperty
from . import constants as consts

class MADDHATT_OT_quick_export_collection(bpy.types.Operator):
    bl_idname = "maddhatt.quick_export_collection"
    bl_label = "You shouldn't be seeing this"
    bl_options = { "INTERNAL", "REGISTER", "UNDO"}

    #  CollectionProperty

    def execute(self, context):
        pass

classes = [
    MADDHATT_OT_quick_export_collection,
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)