import os
import zipfile

    
# Rewrite the __init__.py to add new classes

for root, dirs, files in os.walk(os.getcwd()):
    for file in files:
        if file == "deploy.py":
            export_directory = root


moduleNames = []
for root, dirs, files in os.walk(export_directory):
    for file in files:
        if ".py" in file and "deploy.py" != file and "__init__.py" != file:
            moduleNames.append(file[:-3])
        if "__init__.py" in file:
            loader_path = os.path.join (export_directory, file)

loader_file = open(loader_path, "r")
loader_text = loader_file.readlines()
loader_file.close()

for i, line in enumerate(loader_text):
    if "moduleNames = [" in line:
        loader_text[i] = "moduleNames = " + str(moduleNames) + "\n"
        break

loader_file = open(loader_path, "w")
for line in loader_text:
    loader_file.write(line)
    print(line)
loader_file.close()

zip_name = export_directory.split("\\")[-1] + '.zip'

zfile = zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED)
for root, dirs, files in os.walk(export_directory):
        for file in files:
            zfile.write(os.path.join(root, file), os.path.relpath(os.path.join(root, file),os.path.join(export_directory, '..')))
zfile.close()